var express = require('express');
var cors = require('cors');
var app = express();
var path = require('path');
var fs = require('fs');
var data = {};
var shuData = {};
var FILE_PATH = "./data.json";
var FILE_PATH2 = "./shu.json";

try {
  let dataTex = fs.readFileSync(FILE_PATH, 'utf8');
  data = JSON.parse(dataTex);
  console.log(data)
  let text = fs.readFileSync(FILE_PATH2, 'utf8');
  shuData = JSON.parse(text);
  console.log(shuData);
} catch (err) {
  console.error(err)
}

/*
//设置跨域访问
app.all('*', function(req, res, next) {
	console.log(req);
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By",' 3.2.1')
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
});
*/

//  主页输出 "Hello World"
app.get('/', cors(), function (req, res) {
   console.log("主页 GET 请求");
   res.send('Hello GET');
})
 
 
//  POST 请求
app.post('/', function (req, res) {
   console.log("主页 POST 请求");
   res.send('Hello POST');
})
 
//  /del_user 页面响应
app.get('/del_user', function (req, res) {
   console.log("/del_user 响应 DELETE 请求");
   res.send('删除页面');
})
 
//  /list_user 页面 GET 请求
app.get('/list_user', function (req, res) {
   console.log("/list_user GET 请求");
   res.send('用户列表页面');
})
 
// 对页面 abcd, abxcd, ab123cd, 等响应 GET 请求
app.get('/ab*cd', function(req, res) {   
   console.log("/ab*cd GET 请求");
   res.send('正则匹配');
})
 
// 对页面 abcd, abxcd, ab123cd, 等响应 GET 请求
app.get('/setData', cors(), function(req, res, txt) {   
   console.log(req.query);
   
   let queData = req.query;
   let year = queData.year;
   let moon = queData.moon;
   let day = queData.day;
   let stage = queData.stage;
   let value = queData.value;
	let yearInfo = data[year] = data[year] || {};
	let stageInfo = yearInfo[stage] = yearInfo[stage] || {stage: null, values: null, date: {year: null, moon: null, day: null}};
	stageInfo.values = [value];
	stageInfo.date.year = year;
	stageInfo.date.moon = moon;
	stageInfo.date.day = day;
	stageInfo.stage = stage;
   
   let text = JSON.stringify(data);
   console.log(data);
   fs.writeFileSync(FILE_PATH, text, 'utf8');
   
   res.send(req.query);
})

// 对页面 abcd, abxcd, ab123cd, 等响应 GET 请求
app.get('/getData', cors(), function(req, res) {   
   let dataTex = JSON.stringify(data);
   res.send(dataTex);
})

// 对页面 abcd, abxcd, ab123cd, 等响应 GET 请求
app.get('/getShuData', cors(), function(req, res) {   
   let dataTex = JSON.stringify(shuData);
   res.send(dataTex);
})
 
var server = app.listen(8081, '0.0.0.0', function () {
 
  var host = server.address().address
  var port = server.address().port
 
  console.log("应用实例，访问地址为 http://%s:%s", host, port)
 
})

