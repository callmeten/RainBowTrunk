class GameEvent {
    public static pool: GameEvent[] = [];

    public static create(data: IGameEvent): GameEvent {
        if (!this.pool.length) {
            return new GameEvent(data);
        }
        else {
            let event = this.pool.pop();
            event.initData(data);
            return event
        }
    }

    public static clear(event: GameEvent) {
        event.clear();
        GameEvent.pool.push(event);
    }

    public type: string;
    public listener: Function;
    public thisObj: any;

    constructor(data: IGameEvent) {
        this.initData(data);
    }

    public clear() {
        this.type = null;
        this.listener = null;
        this.thisObj = null;
    }

    public initData(data: IGameEvent) {
        this.type = data.type;
        this.listener = data.listener;
        this.thisObj = data.thisObj;
    }
}

