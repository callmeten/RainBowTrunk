class EnginEvent {
    public static pool: EnginEvent[] = [];

    public static create(data: IEnginEvent): EnginEvent {
        if (!this.pool.length) {
            return new EnginEvent(data);
        }
        else {
            let event = this.pool.pop();
            event.initData(data);
        }
    }

    public static clear(event: EnginEvent) {
        event.clear();
        EnginEvent.pool.push(event);
    }

    public type: string;
    public target: egret.DisplayObject;
    public listener: Function;
    public thisObj: any;
    public priority: number;
    public useCapture: boolean;

    constructor(data: IEnginEvent) {
        this.initData(data);
    }

    public clear() {
        this.target = null;
        this.type = null;
        this.listener = null;
        this.priority = null;
        this.thisObj = null;
        this.useCapture = null;
    }

    public initData(data: IEnginEvent) {
        this.target = data.target;
        this.type = data.type;
        this.listener = data.listener;
        this.priority = data.priority;
        this.thisObj = data.thisObj;
        this.useCapture = data.useCapture;
    }
}

