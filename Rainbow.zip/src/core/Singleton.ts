class Singleton extends egret.HashObject {


    private static _instance: any;

    public static getInstance<T>(): T{
        if (!this._instance) {
            this._instance = new this;
        }
        return this._instance;
    }

    protected constructor () {
        super();

        this.init();
    }

    protected init() {

    }
}