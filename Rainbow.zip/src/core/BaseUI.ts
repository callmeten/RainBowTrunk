class BaseUI extends eui.Component {

    private _id: string;
    
    private _enginEventDic: {[key:string] : EnginEvent[]};
    private _gameEventDic: {[key:string] : GameEvent[]};

    protected initFinish: boolean;

    constructor (id: string) {
        super();

        this._id = id;

        this._enginEventDic = {};
        this._gameEventDic = {};
        
        this.initFinish = false;
        
        this.once(egret.Event.COMPLETE, this.onComplete, this);
    }

    protected getSkinName(): string {
        return `resource/ui_skins/${this._id}.exml`;
    }

    private onComplete() {
        this.initFinish = true;

        this.initEvents();
        this.initData();
        this.initView();
    }

    protected initView() {

    }

    protected initData() {

    }

    protected updateView() {

    }

    public preData(...args: any[]) {
        
    }

    protected initEvents() {

    }

    protected removeEvents() {
        for (let key in this._enginEventDic) {
            let eventList = this._enginEventDic[key];
            eventList.forEach((eventData)=> {
                eventData.target.removeEventListener(eventData.type, eventData.listener, eventData.thisObj, eventData.useCapture);
                EnginEvent.clear(eventData);
            })
            delete this._enginEventDic[key];
        }

        for (let key in this._gameEventDic) {
            let eventList = this._gameEventDic[key];
            eventList.forEach((eventData)=> {
                App.dispatcher.removeEventListener(eventData.type, eventData.listener, eventData.thisObj);
                GameEvent.clear(eventData);
            })

            delete this._gameEventDic[key];
        }
    }

    public addEnginEvent(target: egret.DisplayObject, type: string, listener: Function, thisObject: any, useCapture?: boolean, priority?: number) {
        let eventList: EnginEvent[] = this._enginEventDic[type] = this._enginEventDic[type] = [];

        for (let i = 0; i < eventList.length; i++) {
            let eventData = eventList[i];
            if (eventData.target == target && eventData.listener == listener && eventData.thisObj == this)  return;
        }

        let event = EnginEvent.create({
            target: target,
            type: type,
            listener: listener,
            thisObj: thisObject,
            useCapture: useCapture,
            priority: priority
        })

        eventList.push(event);

        target.addEventListener(type, listener, thisObject, useCapture, priority);
    }

    public removeEnginEvent(target: egret.DisplayObject, type: string, listener: Function, thisObject: any, useCapture?: boolean) {
        let eventList: EnginEvent[] = this._enginEventDic[type] = this._enginEventDic[type];
        if (!eventList || !eventList.length) return;

        for (let i = eventList.length-1; i >= 0; i--) {
            let eventData = eventList[i];
            if (eventData.target == target && eventData.listener == listener && eventData.thisObj == this)  {
                target.removeEventListener(type, listener, thisObject, useCapture);
                let event = eventList.splice(i, 1);
                EnginEvent.clear(event[0]);
                break;
            }
        }

        if (!eventList.length) delete this._enginEventDic[type];
    }

    public addGameEvent(type: string, listener: Function, thisObject: any) {
        let eventList: GameEvent[] = this._gameEventDic[type] = this._gameEventDic[type] = [];

        for (let i = 0; i < eventList.length; i++) {
            let eventData = eventList[i];
            if (eventData.listener == listener && eventData.thisObj == this) return;
        }

        let event: GameEvent = GameEvent.create({
            type: type,
            listener: listener,
            thisObj: thisObject,
        })

        eventList.push(event);

        App.dispatcher.addEventListener(type, listener, thisObject);
    }

    public removeGameEvent(type: string, listener: Function, thisObject: any) {
        let eventList: IGameEvent[] = this._gameEventDic[type] = this._gameEventDic[type];
        if (!eventList || !eventList.length) return;

        for (let i = eventList.length-1; i >= 0; i--) {
            let eventData = eventList[i];
            if (eventData.listener == listener && eventData.thisObj == this) {
                App.dispatcher.removeEventListener(type, listener, thisObject);
                let evnet = eventList.splice(i, 1);
                GameEvent.clear(event[0]);
                break;
            }
        }

        if (!eventList.length) delete this._gameEventDic[type];
    }

    public dispose() {
        this.removeEvents();
        this._gameEventDic = null;
        this._enginEventDic = null;

        this.parent && this.parent.removeChild(this);
    }
}