class DispatchManager extends Singleton {

    private _dispatchDic: {[key:string] : IGameEvent[]};

    protected init() {
        this._dispatchDic = {};
    }

    public addEventListener(type: string, callback: Function, thisObj: any) {
        if (typeof type != "string") {
            console.warn("event type is wrong!");
            return;
        }

        let eventList: IGameEvent[] = this._dispatchDic[type] = this._dispatchDic[type] || [];
        
        for (let i = 0; i < eventList.length; i++) {
            let data = eventList[i];
            if (data.listener == callback && data.thisObj == thisObj) {
                return;
            }
        }

        let eventData: IGameEvent = {
            type: type,
            listener: callback,
            thisObj: thisObj,
        }

        eventList.push(eventData);
    }

    public removeEventListener(type: string, callback: Function, thisObj: any) {
        if (typeof type != "string") {
            console.warn("event type is wrong!");
            return;
        }

        let eventList: IGameEvent[] = this._dispatchDic[type];
        if (!eventList || !eventList.length) return;
        
        for (let i = eventList.length - 1; i >= 0; i--) {
            let data = eventList[i];
            if (data.listener == callback && data.thisObj == thisObj) {
                eventList.splice(i, 1);
                break;
            }
        }

        if (!eventList) delete this._dispatchDic[type];
    }

    public dispatch(type: string, ...param: any[]) {
        if (typeof type != "string") {
            console.warn("event type is wrong!");
            return;
        }

        let eventList: IGameEvent[] = this._dispatchDic[type];
        if (!eventList || !eventList.length) return;

        for (let i = 0; i < eventList.length; i ++) {
            let eventData = eventList[i];
            eventData.listener.apply(eventData.thisObj, param);
        }
    }
}