class App {
    public static mainUI: egret.DisplayObjectContainer;
    public static dispatcher: DispatchManager;
    public static htmlParse: egret.HtmlTextParser;
    public static http: HttpHelp = HttpHelp.getInstance();
    public static date: DateUtil = DateUtil.getInstance();
    public static dataManerger: DataManager;
    public static blueTexture: egret.Texture;
    public static redTexture: egret.Texture;
    public static greenTexture: egret.Texture;
}