interface IData{
    [key: number]: {
        [key:number]: {
            values:number[], 
            date: {
                day: number, 
                moon: number, 
                year: number}, 
            stage: number}
    }
}