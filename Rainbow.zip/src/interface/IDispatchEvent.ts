/** 游戏内自定义的事件参数 */
interface IGameEvent {
    type: string, 
    listener: Function, 
    thisObj?: any, 
}

/** 引擎的事件参数 */
interface IEnginEvent extends IGameEvent {
    target: egret.DisplayObject,
    useCapture? : boolean,
    priority?: number,
}