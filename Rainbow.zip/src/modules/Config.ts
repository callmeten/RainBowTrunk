class Config {
    public static LOCAL = false;
    public static URL = `http://49.234.86.129:8081/`;
    public static LOCAL_URL = `http://localhost:8081/`

    public static getUrl(): string{
        return this.LOCAL ? this.LOCAL_URL : this.URL;
    }

    public static RED_NUMS = [1,13,2,40,29,18,30,7,19,8,45,34,46,23,35,12,24];
    public static GREEN_NUMS = [49,38,27,39,16,28,5,17,6,43,32,44,21,33,22,11];
    public static BLUE_NUMS = [25,37,14,26,3,15,4,41,42,31,20,09,10,47,36,48];
}