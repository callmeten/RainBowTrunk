class HttpHelp extends Singleton {

    private request: egret.HttpRequest;

    private compeleteCallBack: Function;
    private compeleteThis: any;

    private errorCallBack: Function;
    private errorThis: any;

    constructor() {
        super();
    }

    protected init() {
        this.request = new egret.HttpRequest();
        this.request.responseType = egret.HttpResponseType.TEXT;
        this.request.addEventListener(egret.Event.COMPLETE,this.onComplete,this);
        this.request.addEventListener(egret.IOErrorEvent.IO_ERROR,this.onIOError,this);
        this.request.addEventListener(egret.ProgressEvent.PROGRESS,this.onPostProgress,this);
    }

    private onComplete(event:egret.Event) {
        var request = <egret.HttpRequest>event.currentTarget;
        if (this.compeleteCallBack) {
            let callback = this.compeleteCallBack;
            let thisObj = this.compeleteThis;
            this.compeleteCallBack = null;
            this.compeleteThis = null;
            callback.apply(thisObj, [request.response]);
            callback = null;
            thisObj = null;
        }
    }

    private onIOError(event:egret.IOErrorEvent) {
        egret.log("post error : " + event);
    }

    private onPostProgress(event:egret.ProgressEvent):void {
        egret.log("post progress : " + Math.floor(100*event.bytesLoaded/event.bytesTotal) + "%");
    }

    public requestHandler(url: string, callback:Function, thisobj: any, errorCallback?: Function, errorthis?: any) {
        this.compeleteCallBack = callback;
        this.compeleteThis = thisobj;

        this.request.open(url, egret.HttpMethod.GET);
        this.request.send();
    }
}