class FirstItem extends eui.ItemRenderer {

    protected initFinish: boolean = false;

    private img1: eui.Image;
    private img2: eui.Image;
    private img3: eui.Image;
    private img4: eui.Image;
    private img5: eui.Image;

    private colorImg1: eui.Image;
    private colorImg2: eui.Image;
    private colorImg3: eui.Image;
    private colorImg4: eui.Image;
    private colorImg5: eui.Image;

    private numLab1: eui.Label;
    private numLab2: eui.Label;
    private numLab3: eui.Label;
    private numLab4: eui.Label;
    private numLab5: eui.Label;

    private countLab1: eui.Label;
    private countLab2: eui.Label;
    private countLab3: eui.Label;
    private countLab4: eui.Label;
    private countLab5: eui.Label;

    private sumLab: eui.Label;
    private shuLab: eui.Label;

    /** 显示数据对象 */
    private itemData: {name: string, nums: {[key: number]: number}};

    constructor() {
        super()
        this.once(egret.Event.COMPLETE, this.onComplete, this);

        this.skinName = "FirstItemSkin";
    }

    protected onComplete() {
        this.initFinish = true;
        this.dataChanged();
    }

    public dataChanged() {
        if (!this.initFinish || !this.data) return;

        this.itemData = this.data;

        this.shuLab.text = this.itemData.name;

        let keys = Object.keys(this.itemData.nums);
        keys.sort(this.sortKeys);

        let sum: number = 0;
        for (let i = 0; i < 5; i++) {
            let key = keys[i];
            if (!key) {
                UIUtils.setVisible( this[`img${i+1}`], false);
                UIUtils.setVisible( this[`numLab${i+1}`], false);
                UIUtils.setVisible( this[`countLab${i+1}`], false);
                UIUtils.setVisible( this[`colorImg${i+1}`], false);
                continue;
            }

            UIUtils.setVisible( this[`img${i+1}`], true);
            UIUtils.setVisible( this[`numLab${i+1}`], true);
            UIUtils.setVisible( this[`countLab${i+1}`], true);
            UIUtils.setVisible( this[`colorImg${i+1}`], true);

            let value = this.itemData.nums[key];

            this[`numLab${i+1}`].text = StringUtil.fixed2(+keys[i]);
            this[`countLab${i+1}`].text = "+" + value + "次";

            this[`colorImg${i+1}`].source = this.getTexture(+keys[i]);

            sum += value;
        }

        this.sumLab.text = sum + "";
    }

    private getTexture(num: number) {
        if (Config.RED_NUMS.indexOf(num) >= 0) {
            return App.redTexture;
        }
        
        if (Config.GREEN_NUMS.indexOf(num) >= 0) {
            return App.greenTexture;
        }

        if (Config.BLUE_NUMS.indexOf(num) >= 0) {
            return App.blueTexture;
        }
    }

    private sortKeys(v1: string, v2: string) {
        return +v2 - +v1;
    }
}