class DataManager extends Singleton {

    private _data: IData;

    private _shuData: {[key: number]: string};

    constructor() {
        super();
    }

    protected init() {

    }

    public get data() {
        return this._data;
    }

    public initData() {
        let url = Config.getUrl() + 'getData';
        App.http.requestHandler(url, this.onGetData, this);
    }

    private onGetData(resp: string) {
        if (!resp) return;
        this._data = JSON.parse(resp);

        this.initShuData();
    }

    private initShuData() {
        let url = Config.getUrl() + 'getShuData';
        App.http.requestHandler(url, this.onShuData, this);
    }

    private onShuData(resp: string) {
        if (!resp) return;
        this._shuData = JSON.parse(resp);
        let ui = new FirstView();
        ui.preData(this._data);
        App.mainUI.addChild(ui);
    }

    public setData(year: number, moon: number, day: number, stage: number, value: number) {
        let url = `${Config.getUrl()}setData?&year=${year}&moon=${moon}&day=${day}&stage=${stage}&value=${+value}`;

        App.http.requestHandler(url, this.setDataHandler, this);
    }

    protected setDataHandler(res: string) {
        let Object = JSON.parse(res);
        let year: number = Object.year;
        let moon: number = Object.moon;
        let day: number = Object.day;
        let stage: number = Object.stage;
        let value: number = Object.value;

        let yearInfo = this._data[year] = this._data[year] || {};
        let stageInfo = yearInfo[stage] = yearInfo[stage] || {values: null, date: {year: null, moon: null, day: null}, stage: null};
        stageInfo.values = [value];
        stageInfo.date.year = year;
        stageInfo.date.moon = moon;
        stageInfo.date.day = day;
        stageInfo.stage = stage;

        App.dispatcher.dispatch("dataChange");
    }

    public getShuName(num: number) {
        return this._shuData[num+""];
    }
}