class StringUtil {
    public static fixed2(valueNum: number): string {
        let valueStr = valueNum >= 10 ? valueNum + "" : "0" + valueNum;

        return valueStr;
    }

    public static fixed3(valueNum: number): string {
        let valueStr = valueNum >= 100 ? valueNum + "" : "0" + this.fixed2(valueNum);

        return valueStr;
    }

    public static format1(year: number, moon: number, day: number, stage: number, value: number): string {
        let moon1: string = this.fixed2(moon);
        let day1: string = this.fixed2(day);
        let stage1: string = this.fixed3(stage);
        let value1: string = this.fixed2(value);
        return `${year}年${moon1}月${day1}日第<font color='0x071190'>${stage1}</font>期 ${value1}`
    }

    public static format2(year: number, moon: number, day: number, stage: number): string {
        let moon1: string = this.fixed2(moon);
        let day1: string = this.fixed2(day);
        let stage1: string = this.fixed3(stage);
        return `${year}年${moon1}月${day1}日第<font color='0x071190'>${stage1}</font>期`
    }
}