class UIUtils {

    public static setVisible(item: eui.Component, visible: boolean) {
        item.visible = visible;
        // item.includeInLayout = visible;
    }
}