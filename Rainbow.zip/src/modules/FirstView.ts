class FirstView extends BaseUI {

    
    private topList: eui.List;
    private topData: eui.ArrayCollection;
    
    private bottomList: eui.DataGroup;
    private bottomData: eui.ArrayCollection;
    
    private ediLab1: eui.EditableText;
    private ediLab2: eui.EditableText;

    private newDateLab: eui.Label;

    private sCountLab: eui.Label;
    private dCountLab: eui.Label;

    private btn1: eui.Button;
    private btn2: eui.Button;
    private btn3: eui.Button;

    private data: IData;

    private topNumDic: {[key: number]: {name: string, nums: {[key: number]: number}}};

    private inputNum: number;

    private lastStageInfo: {year: number, moon: number, day: number, stage: number};
    private newerStageInfo: {year: number, moon: number, day: number, stage: number};

    constructor() {
        super("FirstView");

        this.skinName = "FirstViewSkin";
    }

    protected initData() {
        this.inputNum = 0;

        this.initTopNumDic();
    }

    protected initEvents() {
        this.addEnginEvent(this.ediLab1, egret.FocusEvent.FOCUS_OUT, this.onEdiLab1Handler, this);
        this.addEnginEvent(this.btn1, egret.TouchEvent.TOUCH_TAP, this._onBtn1Handler, this);
        this.addEnginEvent(this.btn2, egret.TouchEvent.TOUCH_TAP, this._onBtn2Handler, this);
        this.addEnginEvent(this.btn3, egret.TouchEvent.TOUCH_TAP, this._onBtn3Handler, this);

        this.addGameEvent("dataChange", this._onDataChangeHandler, this);
    }

    private initTopNumDic() {
        this.topNumDic = {};

        for (let i = 1; i <= 12; i++) {
            this.topNumDic[i] = {
                name: this.getName(i),
                nums: {}
            };
        }

        for (let i = 1; i < 50; i++) {
            let mod = i % 12;
            let key = mod == 0 ? 12 : mod;
            this.topNumDic[key].nums[i] = 0;
        }
    }

    private getName(id: number): string {
        return App.dataManerger.getShuName(id);
    }

    private clearTopNumDic() {
        for (let num in this.topNumDic) {
            let dataDic = this.topNumDic[num];
            for(let key in dataDic.nums) {
                dataDic.nums[key] = 0;
            }
        }
    }

    protected initView() {
        this.ediLab1.text = "0";
        this.ediLab2.text = "0";

        this.topList.itemRenderer = FirstItem;
        this.topData = new eui.ArrayCollection();
        this.topList.dataProvider = this.topData;

        this.bottomList.itemRenderer = DescLabItem;
        this.bottomData = new eui.ArrayCollection();
        this.bottomList.dataProvider = this.bottomData;

        this.updateView();
    }

    public preData(...args: any[]) {
        if (!args || !args.length) return;

        this.data = args[0];
        this.updateView();
    }

    protected updateView() {
        if(!this.initFinish || !this.data)  return;
        this.updateBottomData();

        this.updateTopData();

        this.updateDSInfo();

        this.updateLastDateInfo()

        this.updateNewerInfo();
    }

    protected updateBottomData() {
        if (!this.data) return
        let dataList = [];

        let keys = Object.keys(this.data);
        keys.sort(this.sorKey);

        for (let key of keys) {
            let datas = this.data[key];
            let datakeys = Object.keys(datas);
            datakeys.sort(this.sorKey);

            for (let stage of datakeys) {
                dataList.push(datas[stage]);
            }
        }

        this.bottomData.replaceAll(dataList);
    }

    protected updateTopData() {
        if (isNaN(this.inputNum)) return;

        
        let mod: number = this.inputNum <= 49 ? this.inputNum % 12 : 0;
        
        let numList: number[] = [];

        if (this.inputNum != 0 && this.inputNum <= 49) {
            for (let i = 0; i < 5; i++) {
                let num: number = mod + i*12;
                if (num <= 49) numList.push(num);
            }
        }

        for (let year in this.data) {
            let yearData = this.data[year];
            for (let stage in yearData) {
                let stageData = yearData[stage];
                let values = stageData.values
                let spNum = +values[values.length-1];
                if (numList.indexOf(spNum) < 0) continue;

                let nextStage = +stage + 1;
                let nextStageData = yearData[nextStage];
                if (!nextStageData) continue;
                let nextTarNum = nextStageData.values[nextStageData.values.length-1];
                this.setTopDataByNum(nextTarNum);
            }
        }

        let list = [];
        for (let key in this.topNumDic) {
            list.push(this.topNumDic[key]);
        }

        this.topData.replaceAll(list);
    }

    private updateNewerInfo () {
        let dateInfo: number[] = App.date.getNextDate(this.lastStageInfo.year, this.lastStageInfo.moon, this.lastStageInfo.day);

        this.newerStageInfo = {
            year: dateInfo[0],
            moon: dateInfo[1],
            day: dateInfo[2],
            stage: +dateInfo[0] != +this.lastStageInfo.year ? 1 : +this.lastStageInfo.stage + 1
        }

        let text: string = StringUtil.format2(this.newerStageInfo.year, this.newerStageInfo.moon, this.newerStageInfo.day, this.newerStageInfo.stage);
        this.newDateLab.textFlow = App.htmlParse.parser(text);
    }

    private updateLastDateInfo() {
        let yearKeys: string[] = Object.keys(this.data);
        yearKeys.sort(this.sorKey);
        let lastYear: string = yearKeys[0];

        let stageList: string[] = Object.keys(this.data[lastYear]);
        stageList.sort(this.sorKey);
        let lastStage: string = stageList[0];

        let lastInfo = this.data[lastYear][lastStage];

        this.lastStageInfo = {
            year: lastInfo.date.year,
            moon: lastInfo.date.moon,
            day: lastInfo.date.day,
            stage: lastInfo.stage
        }
    }

    private updateDSInfo() {
        let double: number = 0;
        let single: number = 0;

        for (let i in this.topNumDic) {
            let dataDic = this.topNumDic[i];
            for (let key in dataDic.nums) {
                let count = dataDic.nums[key];
                if (+count == 0) continue;

                let odd: boolean = +key % 2 != 0;
                if (odd) single += +count;
                else double += +count;
            }
        }
        let text1: string = `单数：<font color='0x071190'>${single}次</font>`
        let text2: string = `双数：<font color='0x071190'>${double}次</font>`
        this.sCountLab.textFlow = App.htmlParse.parse(text1);
        this.dCountLab.textFlow = App.htmlParse.parse(text2);
    }

    protected setTopDataByNum(num: number) {
        let mod = num % 12;
        let key = mod == 0 ? 12 : mod;

        let data = this.topNumDic[key];
        data.nums[num]++;
    }

    private onEdiLab1Handler() {
        let inputString: string = this.ediLab1.text;

        this.clearTopNumDic()

        this.sCountLab.text = "单数：" + 0;
        this.dCountLab.text = "双数：" + 0;

        if (isNaN(+inputString)) return;

        this.inputNum = +inputString;

        this.updateTopData();

        this.updateDSInfo()
    }

    private setDataHandler(res: string) {
        if (!res) return;

        let Object = JSON.parse(res);
        let year: number = Object.year;
        let moon: number = Object.moon;
        let day: number = Object.day;
        let stage: number = Object.stage;
        let value: number = Object.value;

        let yearInfo = this.data[year] = this.data[year] || {};
        let stageInfo = yearInfo[stage] = yearInfo[stage] || {values: null, date: {year: null, moon: null, day: null}, stage: null};
        stageInfo.values = [value];
        stageInfo.date.year = year;
        stageInfo.date.moon = moon;
        stageInfo.date.day = day;
        stageInfo.stage = stage;

        this.updateView();
    }

    private _onBtn1Handler() {
        let inputString: string = this.ediLab2.text;

        if (isNaN(+inputString)) return;

        let year: number = this.newerStageInfo.year;
        let moon: number = this.newerStageInfo.moon;
        let day: number = this.newerStageInfo.day;
        let stage: number = this.newerStageInfo.stage;
        // let url = `${Config.getUrl()}setData?&year=${year}&moon=${moon}&day=${day}&stage=${stage}&value=${+inputString}`;

        // App.http.requestHandler(url, this.setDataHandler, this);
        App.dataManerger.setData(year, moon, day, stage, +inputString);
    }

    private _onBtn2Handler() {
        this.ediLab2.text = null;
    }

    private _onBtn3Handler() {
        let ui = new ChangeRecordView();
        App.mainUI.addChild(ui);
    }

    private _onDataChangeHandler() {
        this.updateView();
        this.updateDSInfo();
    }

    protected sorKey(v1: string, v2: string): number {
        return +v2 - +v1;
    }

}