class DescLabItem extends eui.ItemRenderer {

    protected initFinish: boolean = false;

    public descData: {values:number[], date: {day: number, moon: number, year: number}, stage: number};

    private descLab: eui.Label;

    constructor() {
        super()
        this.once(egret.Event.COMPLETE, this.onComplete, this);

        this.skinName = "DescLabItemSkin";
    }

    protected onComplete() {
        this.initFinish = true;
        this.dataChanged();
    }

    public dataChanged() {
        if (!this.initFinish || !this.data) return;

        this.descData = this.data

        let valueNum = this.descData.values[this.descData.values.length-1];
        let year: number = this.descData.date.year;
        let moon: number = this.descData.date.moon;
        let day: number = this.descData.date.day;
        let stage: number = this.descData.stage;
        let value: number = valueNum;
        let text = StringUtil.format1(year, moon, day, stage, value);

        this.descLab.textFlow = App.htmlParse.parse(text);
    }
}