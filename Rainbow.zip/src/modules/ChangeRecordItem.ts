class ChangeRecordItem extends eui.ItemRenderer {

    protected initFinish: boolean = false;

    public descData: {values:number[], date: {day: number, moon: number, year: number}, stage: number};

    private descLab: eui.Label;

    private ediLab: eui.EditableText;
    private inputNum: number = 0;

    constructor() {
        super()
        this.once(egret.Event.COMPLETE, this.onComplete, this);
        this.skinName = "ChangeRecordItemSkin";
    }

    protected onComplete() {
        this.initFinish = true;

        this.ediLab.addEventListener(egret.FocusEvent.FOCUS_OUT, this.ediLabChangeHandler, this)

        this.dataChanged();
    }

    public dataChanged() {
        if (!this.initFinish || !this.data) return;

        this.descData = this.data

        let valueNum = this.descData.values[this.descData.values.length-1];
        let year: number = this.descData.date.year;
        let moon: number = this.descData.date.moon;
        let day: number = this.descData.date.day;
        let stage: number = this.descData.stage;
        let value: number = valueNum;
        let text = StringUtil.format2(year, moon, day, stage);

        this.ediLab.text = StringUtil.fixed3(value);

        this.descLab.textFlow = App.htmlParse.parse(text);
    }

    protected ediLabChangeHandler() {
        if (isNaN(+this.ediLab.text))return;

        this.inputNum = +this.ediLab.text;

        let year: number = this.descData.date.year;
        let moon: number = this.descData.date.moon;
        let day: number = this.descData.date.day;
        let stage: number = this.descData.stage;
        let value: number = this.inputNum;

        let info = {
            year: year,
            moon: moon,
            day: day,
            stage: stage,
            value: value,
        }

        App.dispatcher.dispatch("commitData", info);
    }
}