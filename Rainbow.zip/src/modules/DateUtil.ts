class DateUtil extends Singleton {

    public DAY_SECOND = 86400;

    private date: Date;

    constructor() {
        super();
    }

    protected init() {
        this.date = new Date();
    }

    public getNextDate(year: number, moon: number, day: number): number[] {
        this.date.setFullYear(year, moon-1, day);

        let dateTime: number = this.date.getTime();

        this.date.setTime(dateTime + this.DAY_SECOND * 1000);

        let nextYear: number = this.date.getFullYear();
        let nextMoon: number = this.date.getMonth();
        let nextDay: number = this.date.getDate();
        return [nextYear, nextMoon+1, nextDay];
    }
}