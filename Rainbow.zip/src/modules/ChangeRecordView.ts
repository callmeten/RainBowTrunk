class ChangeRecordView extends BaseUI {

    private maskImg: eui.Rect;

    private itemList: eui.List;
    private itemData: eui.ArrayCollection;

    private btn1: eui.Button;
    private btn2: eui.Button;

    private data: IData;

    private commitDataList: {year: number, moon: number, day: number, stage: number, value: number}[]

    constructor() {
        super("ChangeRecordView");
        this.skinName = "ChangeRecordViewSkin";
    }

    protected initData() {
        this.data = App.dataManerger.data;

        this.commitDataList = [];
    }

    protected initEvents() {
        this.addEnginEvent(this.btn1, egret.TouchEvent.TOUCH_TAP, this._onBtn1Handler, this);
        this.addEnginEvent(this.btn2, egret.TouchEvent.TOUCH_TAP, this._onBtn2Handler, this);
        this.addEnginEvent(this.maskImg, egret.TouchEvent.TOUCH_TAP, this.dispose, this);

        this.addGameEvent("dataChange", this.onDataHandler, this);
        this.addGameEvent("commitData", this.commintDataHandler, this);
    }

    protected initView() {
        this.itemData = new eui.ArrayCollection();
        this.itemList.itemRenderer = ChangeRecordItem;
        this.itemList.dataProvider = this.itemData;

        this.updateView();
    }
    
    protected updateView() {
        if (!this.initFinish || !this.data) return;

        if (!this.data) return
        let dataList = [];

        let keys = Object.keys(this.data);
        keys.sort(this.sorKey);

        for (let key of keys) {
            let datas = this.data[key];
            let datakeys = Object.keys(datas);
            datakeys.sort(this.sorKey);

            for (let stage of datakeys) {
                dataList.push(datas[stage]);
            }
        }

        this.itemData.replaceAll(dataList);
    }

    
    protected sorKey(v1: string, v2: string): number {
        return +v2 - +v1;
    }

    private _onBtn1Handler() {
        if (!this.commitDataList || !this.commitDataList.length) return;

        for (let i = 0; i < this.commitDataList.length; i++) {
            let info = this.commitDataList[i];
            App.dataManerger.setData(info.year, info.moon, info.day, info.stage, info.value);
        }

        this.commitDataList.length = 0;
    }

    private _onBtn2Handler() {
        this.commitDataList.length = 0;
        this.updateView();
    }

    private onDataHandler() {
        this.updateView();
    } 

    private commintDataHandler(info: {year: number, moon: number, day: number, stage: number, value: number}) {
        this.commitDataList.push(info);
    }
}